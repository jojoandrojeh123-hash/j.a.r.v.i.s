from pathlib import Path
from llama_cpp import Llama
from config import settings
from model_manager import model_manager
import logging
import threading
from typing import Optional, Generator

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class LLMEngine:
    def __init__(self):
        self.model: Optional[Llama] = None
        self.current_model_id: Optional[str] = None
        self.system_prompt = self._load_system_prompt()
        self.conversation_history = []
        self._stop_event = threading.Event()

    def _load_system_prompt(self) -> str:
        prompt_path = Path(settings.SYSTEM_PROMPT_FILE)
        if prompt_path.exists():
            return prompt_path.read_text(encoding='utf-8')
        return "You are a helpful AI assistant."

    def reload_system_prompt(self):
        self.system_prompt = self._load_system_prompt()
        self.conversation_history = []
        logger.info("System prompt reloaded")

    def initialize(self, model_id: Optional[str] = None) -> bool:
        if model_manager.needs_model():
            logger.warning("No models downloaded.")
            return False
        if model_id:
            model_path = model_manager.get_model_path(model_id)
            if not model_path:
                logger.error(f"Model {model_id} not found")
                return False
        else:
            default_model = model_manager.get_default_model()
            if not default_model:
                return False
            model_id = default_model["id"]
            model_path = default_model["path"]

        if self.model and self.current_model_id == model_id:
            return True

        try:
            logger.info(f"Loading model: {model_id}...")
            if self.model:
                del self.model
                self.model = None
            self.model = Llama(
                model_path=model_path,
                n_ctx=settings.N_CTX,
                n_gpu_layers=settings.N_GPU_LAYERS,
                verbose=False
            )
            self.current_model_id = model_id
            logger.info(f"Model {model_id} loaded successfully!")
            return True
        except Exception as e:
            logger.error(f"Failed to load model: {e}")
            return False

    def switch_model(self, model_id: str) -> bool:
        return self.initialize(model_id)

    def stop(self):
        """Signal the current generation to stop."""
        self._stop_event.set()

    def _build_prompt(self, user_message: str) -> str:
        """ChatML format for Qwen2.5 and compatible models."""
        prompt = f"<|im_start|>system\n{self.system_prompt}<|im_end|>\n"
        for exchange in self.conversation_history[-10:]:
            prompt += f"<|im_start|>user\n{exchange['user']}<|im_end|>\n"
            prompt += f"<|im_start|>assistant\n{exchange['assistant']}<|im_end|>\n"
        prompt += f"<|im_start|>user\n{user_message}<|im_end|>\n<|im_start|>assistant\n"
        return prompt

    def generate(self, user_message: str, stream: bool = False):
        if not self.model:
            raise RuntimeError("No model loaded.")
        prompt = self._build_prompt(user_message)
        if stream:
            return self._generate_stream(prompt, user_message)
        else:
            return self._generate_complete(prompt, user_message)

    def _generate_complete(self, prompt: str, user_message: str) -> str:
        self._stop_event.clear()
        output = self.model(
            prompt,
            max_tokens=settings.MAX_TOKENS,
            temperature=settings.TEMPERATURE,
            stop=["<|im_end|>", "<|im_start|>"],
            echo=False
        )
        response = output['choices'][0]['text'].strip()
        self.conversation_history.append({'user': user_message, 'assistant': response})
        return response

    def _generate_stream(self, prompt: str, user_message: str) -> Generator:
        self._stop_event.clear()
        full_response = ""
        for output in self.model(
            prompt,
            max_tokens=settings.MAX_TOKENS,
            temperature=settings.TEMPERATURE,
            stop=["<|im_end|>", "<|im_start|>"],
            echo=False,
            stream=True
        ):
            if self._stop_event.is_set():
                logger.info("Generation stopped by user")
                break
            token = output['choices'][0]['text']
            full_response += token
            yield token

        self.conversation_history.append({
            'user': user_message,
            'assistant': full_response.strip()
        })

    def clear_history(self):
        self.conversation_history = []
        logger.info("Conversation history cleared")

    def get_status(self) -> dict:
        return {
            "model_loaded": self.model is not None,
            "current_model": self.current_model_id,
            "history_length": len(self.conversation_history)
        }


llm_engine = LLMEngine()