"""
docker_sandbox.py — Full container management for LocalAI sandbox.

Workspace layout (host-side):  ./sandbox_workspace/
  home/          → /workspace/home/      (user work area, writable)
  outputs/       → /workspace/outputs/   (files ready to download)
  tmp/           → /workspace/tmp/       (temp execution files, auto-cleaned)

Inside container: /workspace/ is the root, matching the above.
"""

import subprocess
import json
import uuid
import shutil
import time
from pathlib import Path
from typing import Optional
import logging

logger = logging.getLogger(__name__)

CONTAINER_NAME  = "localai-sandbox"
IMAGE           = "python:3.11-slim"

# Host-side workspace root
WORKSPACE_DIR   = Path("sandbox_workspace").resolve()

# Sub-directories (created on demand)
HOME_DIR        = WORKSPACE_DIR / "home"
OUTPUTS_DIR     = WORKSPACE_DIR / "outputs"
TMP_DIR         = WORKSPACE_DIR / "tmp"

# Paths inside the container
CONTAINER_ROOT  = "/workspace"
CONTAINER_HOME  = "/workspace/home"
CONTAINER_OUT   = "/workspace/outputs"
CONTAINER_TMP   = "/workspace/tmp"

# Resource limits (can be overridden via settings)
DEFAULT_MEM     = "1g"
DEFAULT_CPUS    = "2.0"
DEFAULT_TIMEOUT = 30   # seconds per exec


def _ensure_dirs():
    for d in [WORKSPACE_DIR, HOME_DIR, OUTPUTS_DIR, TMP_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def _run(cmd: list, capture=True, timeout=60) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(cmd, capture_output=capture, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(cmd, -1, "", "Command timed out")
    except FileNotFoundError:
        return subprocess.CompletedProcess(cmd, -1, "", "Docker not found in PATH")


def is_docker_available() -> bool:
    r = _run(["docker", "info"], timeout=10)
    return r.returncode == 0


def container_status() -> dict:
    """Return detailed container status."""
    r = _run(["docker", "inspect", "--format",
        "{{.State.Status}}|{{.State.StartedAt}}|{{.State.FinishedAt}}|{{.Config.Image}}",
        CONTAINER_NAME])
    if r.returncode != 0:
        return {"running": False, "status": "not_found", "started": None,
                "image": None, "resource_limits": None}

    parts = r.stdout.strip().split("|")
    status = parts[0] if parts else "unknown"

    # Get resource stats if running
    stats = {}
    if status == "running":
        sr = _run(["docker", "stats", CONTAINER_NAME,
                   "--no-stream", "--format",
                   "{{.CPUPerc}}|{{.MemUsage}}|{{.MemPerc}}"], timeout=10)
        if sr.returncode == 0 and sr.stdout.strip():
            sp = sr.stdout.strip().split("|")
            stats = {
                "cpu_percent": sp[0] if sp else "?",
                "mem_usage": sp[1] if len(sp)>1 else "?",
                "mem_percent": sp[2] if len(sp)>2 else "?",
            }

    return {
        "running": status == "running",
        "status": status,
        "started": parts[1] if len(parts) > 1 else None,
        "finished": parts[2] if len(parts) > 2 else None,
        "image": parts[3] if len(parts) > 3 else IMAGE,
        "stats": stats,
        "workspace": str(WORKSPACE_DIR),
    }


def ensure_container(mem: str = DEFAULT_MEM, cpus: str = DEFAULT_CPUS) -> dict:
    """Start the sandbox container if it isn't already running."""
    _ensure_dirs()

    r = _run(["docker", "inspect", "--format", "{{.State.Status}}", CONTAINER_NAME])
    if r.returncode == 0:
        current = r.stdout.strip()
        if current == "running":
            return {"ok": True, "msg": "Container already running", "action": "none"}
        # Remove stopped/exited container
        _run(["docker", "rm", "-f", CONTAINER_NAME])

    # Pull image if needed
    _run(["docker", "pull", IMAGE], timeout=120)

    r = _run([
        "docker", "run", "-d",
        "--name", CONTAINER_NAME,
        "--restart", "unless-stopped",
        "-v", f"{WORKSPACE_DIR}:{CONTAINER_ROOT}",
        "-w", CONTAINER_HOME,
        "--memory", mem,
        "--cpus", cpus,
        "--network", "bridge",
        IMAGE,
        "bash", "-c",
        f"mkdir -p {CONTAINER_HOME} {CONTAINER_OUT} {CONTAINER_TMP} && sleep infinity"
    ], timeout=30)

    if r.returncode != 0:
        return {"ok": False, "msg": r.stderr.strip() or "Failed to start container"}

    # Install base packages
    pkg_r = _run([
        "docker", "exec", CONTAINER_NAME,
        "pip", "install", "-q", "--break-system-packages",
        "requests", "numpy", "pandas", "matplotlib", "pillow"
    ], timeout=180)

    return {
        "ok": True,
        "msg": "Container started successfully",
        "action": "started",
        "packages_installed": pkg_r.returncode == 0,
        "image": IMAGE,
        "mem": mem,
        "cpus": cpus,
    }


def stop_container() -> dict:
    r = _run(["docker", "rm", "-f", CONTAINER_NAME])
    return {"ok": r.returncode == 0, "msg": "Container stopped" if r.returncode == 0 else r.stderr.strip()}


def restart_container() -> dict:
    stop_container()
    return ensure_container()


def install_packages(packages: list[str], manager: str = "pip") -> dict:
    """Install packages inside the container."""
    _ensure_container_running()
    if not packages:
        return {"ok": False, "msg": "No packages specified"}

    if manager == "pip":
        cmd = ["docker", "exec", CONTAINER_NAME,
               "pip", "install", "-q", "--break-system-packages"] + packages
    elif manager == "apt":
        _run(["docker", "exec", CONTAINER_NAME, "apt-get", "update", "-q"])
        cmd = ["docker", "exec", CONTAINER_NAME,
               "apt-get", "install", "-y", "-q"] + packages
    elif manager == "npm":
        cmd = ["docker", "exec", CONTAINER_NAME, "npm", "install", "-g"] + packages
    else:
        return {"ok": False, "msg": f"Unknown package manager: {manager}"}

    r = _run(cmd, timeout=180)
    return {
        "ok": r.returncode == 0,
        "stdout": r.stdout[:3000],
        "stderr": r.stderr[:1000],
        "packages": packages,
        "manager": manager,
    }


def list_installed_packages(manager: str = "pip") -> dict:
    """List packages installed in the container."""
    _ensure_container_running()
    if manager == "pip":
        r = _run(["docker", "exec", CONTAINER_NAME, "pip", "list", "--format=json"])
        if r.returncode == 0:
            try:
                pkgs = json.loads(r.stdout)
                return {"ok": True, "packages": pkgs, "manager": "pip"}
            except Exception:
                pass
    elif manager == "apt":
        r = _run(["docker", "exec", CONTAINER_NAME, "dpkg", "--get-selections"])
    elif manager == "npm":
        r = _run(["docker", "exec", CONTAINER_NAME, "npm", "list", "-g", "--depth=0"])

    return {"ok": r.returncode == 0, "raw": r.stdout[:5000], "manager": manager}


def exec_shell(command: str, workdir: str = CONTAINER_HOME, timeout: int = DEFAULT_TIMEOUT) -> dict:
    """Run any shell command inside the container."""
    _ensure_container_running()
    r = _run([
        "docker", "exec", "-w", workdir,
        CONTAINER_NAME, "bash", "-c", command
    ], timeout=timeout)
    return {
        "ok": r.returncode == 0,
        "stdout": r.stdout[:10000],
        "stderr": r.stderr[:3000],
        "exit_code": r.returncode,
        "command": command,
    }


def exec_code(code: str, language: str = "python", timeout: int = DEFAULT_TIMEOUT) -> dict:
    """Execute a code snippet inside the container."""
    _ensure_container_running()
    ext = {"python": "py", "bash": "sh", "javascript": "js", "node": "js"}.get(language, "txt")
    fname = f"_exec_{uuid.uuid4().hex[:8]}.{ext}"
    host_tmp = TMP_DIR / fname
    container_tmp = f"{CONTAINER_TMP}/{fname}"

    try:
        host_tmp.write_text(code, encoding="utf-8")

        if language in ("python", "py"):
            cmd_args = ["python", container_tmp]
        elif language in ("bash", "sh"):
            cmd_args = ["bash", container_tmp]
        elif language in ("javascript", "js", "node"):
            cmd_args = ["node", container_tmp]
        else:
            return {"ok": False, "stdout": "", "stderr": f"Unsupported: {language}", "exit_code": 1}

        r = _run(["docker", "exec", "-w", CONTAINER_HOME, CONTAINER_NAME] + cmd_args, timeout=timeout)
        return {
            "ok": r.returncode == 0,
            "stdout": r.stdout[:10000],
            "stderr": r.stderr[:3000],
            "exit_code": r.returncode,
            "language": language,
        }
    except Exception as e:
        return {"ok": False, "stdout": "", "stderr": str(e), "exit_code": -1}
    finally:
        try: host_tmp.unlink()
        except: pass


def write_file(rel_path: str, content: str, area: str = "home") -> dict:
    """
    Write a file into the workspace.
    area: 'home' → /workspace/home/ (work area)
          'outputs' → /workspace/outputs/ (downloadable)
    """
    _ensure_dirs()
    base = HOME_DIR if area == "home" else OUTPUTS_DIR
    target = (base / rel_path).resolve()
    if not str(target).startswith(str(WORKSPACE_DIR)):
        return {"ok": False, "msg": "Path escapes workspace"}
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    rel = str(target.relative_to(WORKSPACE_DIR)).replace("\\", "/")
    downloadable = str(target).startswith(str(OUTPUTS_DIR))
    return {
        "ok": True,
        "path": str(target),
        "rel_path": rel,
        "downloadable": downloadable,
        "size": target.stat().st_size,
    }


def copy_to_outputs(rel_path: str) -> dict:
    """Copy a file from home/ to outputs/ to make it downloadable."""
    src = (HOME_DIR / rel_path).resolve()
    if not src.exists():
        return {"ok": False, "msg": f"Source not found: {rel_path}"}
    dst = OUTPUTS_DIR / src.name
    shutil.copy2(src, dst)
    return {
        "ok": True,
        "source": str(src),
        "output": str(dst),
        "filename": src.name,
        "size": dst.stat().st_size,
    }


def read_file(rel_path: str) -> dict:
    target = (WORKSPACE_DIR / rel_path).resolve()
    if not str(target).startswith(str(WORKSPACE_DIR)):
        return {"ok": False, "content": "", "msg": "Path escapes workspace"}
    if not target.exists():
        return {"ok": False, "content": "", "msg": "File not found"}
    try:
        content = target.read_text(encoding="utf-8", errors="replace")
        return {"ok": True, "content": content, "size": len(content)}
    except Exception as e:
        return {"ok": False, "content": "", "msg": str(e)}


def list_files(rel_path: str = "", area: str = "home") -> dict:
    """
    List files.
    area: 'home' | 'outputs' | 'all'
    rel_path: subdirectory within the area
    """
    _ensure_dirs()
    if area == "outputs":
        base = OUTPUTS_DIR
    elif area == "all":
        base = WORKSPACE_DIR
    else:
        base = HOME_DIR

    target = (base / rel_path).resolve() if rel_path else base
    if not str(target).startswith(str(WORKSPACE_DIR)):
        return {"ok": False, "entries": [], "msg": "Path escapes workspace"}
    if not target.exists():
        return {"ok": False, "entries": [], "msg": "Directory not found"}

    entries = []
    for item in sorted(target.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
        try:
            rel = str(item.relative_to(WORKSPACE_DIR)).replace("\\", "/")
            entries.append({
                "name": item.name,
                "is_dir": item.is_dir(),
                "size": item.stat().st_size if item.is_file() else 0,
                "modified": item.stat().st_mtime,
                "rel_path": rel,
                "downloadable": str(item).startswith(str(OUTPUTS_DIR)),
                "area": "outputs" if str(item).startswith(str(OUTPUTS_DIR)) else "home",
            })
        except Exception:
            pass
    return {
        "ok": True,
        "entries": entries,
        "cwd": str(target.relative_to(WORKSPACE_DIR)).replace("\\", "/") or "/",
        "area": area,
    }


def delete_file(rel_path: str) -> dict:
    target = (WORKSPACE_DIR / rel_path).resolve()
    if not str(target).startswith(str(WORKSPACE_DIR)):
        return {"ok": False, "msg": "Path escapes workspace"}
    if not target.exists():
        return {"ok": False, "msg": "Not found"}
    name = target.name
    if target.is_dir():
        shutil.rmtree(target)
    else:
        target.unlink()
    return {"ok": True, "deleted": name}


def get_container_logs(lines: int = 50) -> dict:
    r = _run(["docker", "logs", "--tail", str(lines), CONTAINER_NAME])
    return {
        "ok": r.returncode == 0,
        "stdout": r.stdout,
        "stderr": r.stderr,
    }


def clean_tmp() -> dict:
    """Remove all temp execution files."""
    _ensure_dirs()
    count = 0
    for f in TMP_DIR.glob("_exec_*"):
        try: f.unlink(); count += 1
        except: pass
    return {"ok": True, "cleaned": count}


def workspace_summary() -> dict:
    """Return counts and sizes for the workspace areas."""
    _ensure_dirs()
    def area_info(path: Path):
        files = [f for f in path.rglob("*") if f.is_file()]
        return {
            "file_count": len(files),
            "total_size": sum(f.stat().st_size for f in files),
        }
    return {
        "ok": True,
        "home": area_info(HOME_DIR),
        "outputs": area_info(OUTPUTS_DIR),
        "tmp": area_info(TMP_DIR),
        "workspace_path": str(WORKSPACE_DIR),
    }


def _ensure_container_running():
    """Auto-start if not running."""
    r = _run(["docker", "inspect", "--format", "{{.State.Status}}", CONTAINER_NAME], timeout=5)
    if r.returncode != 0 or r.stdout.strip() != "running":
        ensure_container()