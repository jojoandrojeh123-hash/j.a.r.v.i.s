# J.A.R.V.I.S. AI Assistant - Code Review Report

**Branch:** `jarvis-ai-assistant`
**Date:** 2026-07-19
**Scope:** Full review of backend (Python/FastAPI), frontend (static JS), Docker, and docs.

---

## 1. Critical Bugs (will break at runtime)

### 1.1 `AttributeError` on `model_manager.MAX_MODELS` (`main.py`)
In the `/api/models` download handler:
```python
detail=f"Maximum {model_manager.MAX_MODELS} models allowed. Delete one first."
```
`MAX_MODELS` is a **module-level constant** in `model_manager.py`, not an attribute of the `ModelManager` class. When a user hits the download limit, this line raises `AttributeError` and returns a 500 instead of the intended 400.

**Fix:** import the constant directly (`from model_manager import MAX_MODELS`) or make it a class attribute (`ModelManager.MAX_MODELS = MAX_MODELS`).

### 1.2 Docker health check uses `curl`, but `curl` is never installed (`Dockerfile`)
```dockerfile
HEALTHCHECK ... CMD curl -f http://localhost:8000/api/health || exit 1
```
`python:3.11-slim` does not ship `curl`, and it is not in the `apt-get install` list. The container will **always report unhealthy**.

**Fix:** add `curl` to the apt install list, or use a Python one-liner:
```dockerfile
CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/api/health')" || exit 1
```

### 1.3 Blocking calls inside async handlers (event loop freeze)
- `/api/chat` calls the synchronous `llm_engine.generate()` inside an `async def` handler.
- `/api/models` (download) calls `model_manager.download_model()`, which uses synchronous `requests` to download a **4.4 GB** file. The entire server (all requests + WebSockets) freezes until the download completes.
- The WebSocket streaming loop iterates a synchronous llama-cpp generator, blocking the event loop between tokens.

**Fix:** wrap blocking work with `await asyncio.to_thread(...)` (or `run_in_executor`), and stream tokens via a thread + `asyncio.Queue`.

---

## 2. Security Issues (high priority)

1. **No authentication anywhere.** The server binds `0.0.0.0` with `ENABLE_SYSTEM_CONTROL=true` by default. Anyone who can reach port 8000 gets **remote code execution** via `/api/system` (`execute` action runs `subprocess.run(command, shell=True)`).
2. **Dangerous-command blocklist is trivially bypassed** (`system_control.py`). Patterns like `rm -rf /` won't catch `rm -rf /*`, `rm -rf ~`, encoded or chained commands. `ALLOWED_COMMANDS` exists in `config.py` but is **never used**. Replace the blocklist with an allowlist.
3. **Path traversal:** `read_file` / `write_file` accept any absolute path (`Path(path).expanduser().resolve()`) with no base-directory restriction. Any file readable/writable by the process is exposed.
4. **XSS in `static/app.js`:** `formatMessage()` builds HTML from raw text and injects it via `innerHTML` without escaping. User input or LLM output containing `<script>`/`<img onerror=...>` executes in the browser. Escape HTML before applying markdown formatting.
5. **Chat text implicitly triggers system actions:** any message containing `"open "` launches an application (`process_system_command` in `main.py`), e.g. "how do I open a file?" would try to launch `a`.

---

## 3. Functional / Logic Issues (medium)

1. **Malformed Mistral prompt format** (`llm_engine.py`): the whole history is stuffed inside a single `[INST] ... [/INST]` block, and `"User:"` is used as a stop string, which can truncate legitimate responses that mention "User:". Use proper per-turn `[INST]...[/INST]` pairs or `create_chat_completion()`.
2. **Stale state on failed model switch:** `initialize()` unloads the old model before loading the new one; if `Llama()` raises, `self.model` is `None` but `current_model_id` still points to the old model, so status reporting lies.
3. **Unbounded memory growth:** `conversation_history` is never trimmed (only the last 10 entries are used in prompts, but the list grows forever).
4. **Pydantic v2 warning:** field `model_id` in `ModelAction` collides with the protected `model_` namespace. Add `model_config = ConfigDict(protected_namespaces=())`.
5. **Screenshots are not persisted in Docker:** `docker-compose.yml` mounts `./screenshots:/app/screenshots`, but `take_screenshot()` saves to the working directory (`/app`). Also `pyautogui` cannot capture the screen in a headless container.
6. **Dead settings:** `MODEL_PATH` and `MODEL_URL` in `config.py` are superseded by `model_manager.py` and never used.
7. **Custom GGUF files are ignored:** `get_downloaded_models()` only matches filenames hard-coded in `AVAILABLE_MODELS`, so a model dropped into `models/` is invisible unless registered (see README section "Adding Your Own Local Model").
8. **`uvicorn.run(reload=True)`** in `main.py` is a dev setting; disable for production.

---

## 4. Documentation Inaccuracies

1. README claimed "model will auto-download on first run" - false; the model must be downloaded via the web UI. (Fixed in this commit.)
2. `CMAKE_ARGS="-DLLAMA_CUBLAS=on"` is deprecated in recent llama-cpp-python; use `-DGGML_CUDA=on`.

---

## 5. Dependency Notes

- `pyttsx3`, `SpeechRecognition`, and `pyaudio` are **unused by the backend** (voice is handled in the browser via the Web Speech API). They bloat the Docker image and force the portaudio build dependencies. Consider removing them.
- Version pins are otherwise consistent.

---

## 6. Recommended Fix Priority

| # | Issue | Severity |
|---|-------|----------|
| 1 | Unauthenticated RCE via `/api/system` | Critical |
| 2 | `model_manager.MAX_MODELS` AttributeError | Critical |
| 3 | Blocking calls freeze the async server | High |
| 4 | Docker health check missing `curl` | High |
| 5 | XSS via `innerHTML` in `app.js` | High |
| 6 | Path traversal in read/write file | High |
| 7 | Mistral prompt format / stop tokens | Medium |
| 8 | Stale state on failed model switch | Medium |
| 9 | Pydantic `model_id` namespace warning | Low |
| 10 | Dead config settings, unused deps | Low |
