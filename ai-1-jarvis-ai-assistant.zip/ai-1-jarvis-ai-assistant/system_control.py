import os
import sys
import subprocess
import platform
import psutil
import json
from pathlib import Path
from typing import Dict, Any, Optional
from config import settings
import logging

logger = logging.getLogger(__name__)

class SystemController:
    """Controls system operations - use with caution!"""
    
    def __init__(self):
        self.os_type = platform.system().lower()
        self.is_windows = self.os_type == 'windows'
        self.is_mac = self.os_type == 'darwin'
        self.is_linux = self.os_type == 'linux'
        
    def execute_command(self, command: str, safe_mode: bool = True) -> Dict[str, Any]:
        """Execute a shell command."""
        if not settings.ENABLE_SYSTEM_CONTROL:
            return {"success": False, "error": "System control is disabled"}
        
        # Safety check
        dangerous_patterns = ['rm -rf /', 'format', 'del /f /s /q', ':(){:|:&};:']
        if safe_mode:
            for pattern in dangerous_patterns:
                if pattern in command.lower():
                    return {"success": False, "error": f"Blocked dangerous command pattern: {pattern}"}
        
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30
            )
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "return_code": result.returncode
            }
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Command timed out"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def open_application(self, app_name: str) -> Dict[str, Any]:
        """Open an application by name."""
        try:
            if self.is_cwindows:
                os.startfile(app_name)
            elif self.is_mac:
                subprocess.Popen(['open', '-a', app_name])
            else:  # Linux
                subprocess.Popen([app_name])
            return {"success": True, "message": f"Opened {app_name}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def open_url(self, url: str) -> Dict[str, Any]:
        """Open a URL in the default browser."""
        import webbrowser
        try:
            webbrowser.open(url)
            return {"success": True, "message": f"Opened {url}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_system_info(self) -> Dict[str, Any]:
        """Get system information."""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            return {
                "success": True,
                "data": {
                    "os": platform.system(),
                    "os_version": platform.version(),
                    "hostname": platform.node(),
                    "cpu_percent": cpu_percent,
                    "memory_total_gb": round(memory.total / (1024**3), 2),
                    "memory_used_percent": memory.percent,
                    "disk_total_gb": round(disk.total / (1024**3), 2),
                    "disk_used_percent": round((disk.used / disk.total) * 100, 2),
                    "python_version": platform.python_version()
                }
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def list_directory(self, path: str = ".") -> Dict[str, Any]:
        """List contents of a directory."""
        try:
            p = Path(path).expanduser().resolve()
            if not p.exists():
                return {"success": False, "error": "Path does not exist"}
            
            items = []
            for item in p.iterdir():
                items.append({
                    "name": item.name,
                    "type": "directory" if item.is_dir() else "file",
                    "size": item.stat().st_size if item.is_file() else None
                })
            
            return {"success": True, "path": str(p), "items": items}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def read_file(self, path: str) -> Dict[str, Any]:
        """Read contents of a file."""
        try:
            p = Path(path).expanduser().resolve()
            if not p.exists():
                return {"success": False, "error": "File does not exist"}
            if not p.is_file():
                return {"success": False, "error": "Path is not a file"}
            
            # Limit file size
            if p.stat().st_size > 1024 * 1024:  # 1MB limit
                return {"success": False, "error": "File too large (>1MB)"}
            
            content = p.read_text()
            return {"success": True, "content": content}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def write_file(self, path: str, content: str) -> Dict[str, Any]:
        """Write content to a file."""
        try:
            p = Path(path).expanduser().resolve()
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content)
            return {"success": True, "message": f"Written to {p}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_running_processes(self, limit: int = 20) -> Dict[str, Any]:
        """Get list of running processes."""
        try:
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
                try:
                    processes.append(proc.info)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            
            # Sort by CPU usage
            processes.sort(key=lambda x: x.get('cpu_percent', 0), reverse=True)
            return {"success": True, "processes": processes[:limit]}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def kill_process(self, pid: int) -> Dict[str, Any]:
        """Kill a process by PID."""
        try:
            proc = psutil.Process(pid)
            proc.terminate()
            return {"success": True, "message": f"Terminated process {pid}"}
        except psutil.NoSuchProcess:
            return {"success": False, "error": "Process not found"}
        except psutil.AccessDenied:
            return {"success": False, "error": "Access denied"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def set_volume(self, level: int) -> Dict[str, Any]:
        """Set system volume (0-100)."""
        level = max(0, min(100, level))
        try:
            if self.is_mac:
                subprocess.run(['osascript', '-e', f'set volume output volume {level}'])
            elif self.is_linux:
                subprocess.run(['amixer', 'set', 'Master', f'{level}%'])
            elif self.is_windows:
                # Requires nircmd or similar
                pass
            return {"success": True, "message": f"Volume set to {level}%"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def take_screenshot(self, save_path: Optional[str] = None) -> Dict[str, Any]:
        """Take a screenshot."""
        try:
            import pyautogui
            from datetime import datetime
            
            if not save_path:
                save_path = f"screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            
            screenshot = pyautogui.screenshot()
            screenshot.save(save_path)
            return {"success": True, "path": save_path}
        except Exception as e:
            return {"success": False, "error": str(e)}

# Global instance
system_controller = SystemController()
