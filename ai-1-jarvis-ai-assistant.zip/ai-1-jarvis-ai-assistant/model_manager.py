import os
import requests
from pathlib import Path
from typing import List, Dict, Optional
from config import settings
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Available models to download
AVAILABLE_MODELS = {
    "mistral-7b": {
        "name": "Mistral 7B Instruct v0.2",
        "filename": "mistral-7b-instruct-v0.2.Q4_K_M.gguf",
        "url": "https://huggingface.co/TheBloke/Mistral-7B-Instruct-v0.2-GGUF/resolve/main/mistral-7b-instruct-v0.2.Q4_K_M.gguf",
        "size_gb": 4.4,
        "description": "Best overall quality, good for complex tasks"
    },
    "phi-2": {
        "name": "Phi-2 (2.7B)",
        "filename": "phi-2.Q4_K_M.gguf",
        "url": "https://huggingface.co/TheBloke/phi-2-GGUF/resolve/main/phi-2.Q4_K_M.gguf",
        "size_gb": 1.6,
        "description": "Smaller and faster, good for quick responses"
    }
}

MAX_MODELS = 10  # Raised from 2 so local models don't hit the cap
MIN_MODELS = 1


class ModelManager:
    """Manages GGUF model downloads and selection."""
    
    def __init__(self):
        self.models_dir = Path(settings.MODELS_DIR)
        self.models_dir.mkdir(parents=True, exist_ok=True)
        self.current_model: Optional[str] = None
        
    def get_downloaded_models(self) -> List[Dict]:
        """Get list of downloaded models in the models folder.
        
        Detects BOTH predefined models (from AVAILABLE_MODELS) AND any
        custom .gguf files dropped manually into the models/ directory.
        """
        downloaded = []
        seen_filenames = set()

        # 1. Check predefined models first (preserves their metadata)
        for model_id, model_info in AVAILABLE_MODELS.items():
            model_path = self.models_dir / model_info["filename"]
            if model_path.exists():
                downloaded.append({
                    "id": model_id,
                    "name": model_info["name"],
                    "filename": model_info["filename"],
                    "path": str(model_path),
                    "size_gb": model_info["size_gb"],
                    "description": model_info["description"]
                })
                seen_filenames.add(model_info["filename"])

        # 2. Scan for any additional .gguf files not in AVAILABLE_MODELS
        for gguf_file in sorted(self.models_dir.glob("*.gguf")):
            if gguf_file.name in seen_filenames:
                continue  # Already added above
            model_id = gguf_file.stem  # e.g. "llama-3-8b-q4" from "llama-3-8b-q4.gguf"
            size_gb = round(gguf_file.stat().st_size / 1_000_000_000, 2)
            downloaded.append({
                "id": model_id,
                "name": gguf_file.name,
                "filename": gguf_file.name,
                "path": str(gguf_file),
                "size_gb": size_gb,
                "description": "Local model"
            })
            seen_filenames.add(gguf_file.name)

        return downloaded
    
    def get_available_for_download(self) -> List[Dict]:
        """Get predefined models that can still be downloaded."""
        downloaded_filenames = {m["filename"] for m in self.get_downloaded_models()}
        available = []
        
        for model_id, model_info in AVAILABLE_MODELS.items():
            if model_info["filename"] not in downloaded_filenames:
                available.append({
                    "id": model_id,
                    "name": model_info["name"],
                    "filename": model_info["filename"],
                    "url": model_info["url"],
                    "size_gb": model_info["size_gb"],
                    "description": model_info["description"]
                })
        
        return available
    
    def can_download_more(self) -> bool:
        """Check if more models can be downloaded."""
        return len(self.get_downloaded_models()) < MAX_MODELS
    
    def needs_model(self) -> bool:
        """Check if at least one model is needed."""
        return len(self.get_downloaded_models()) < MIN_MODELS
    
    def should_prompt_for_additional(self) -> bool:
        """Check if we should ask user to download an additional model."""
        downloaded = len(self.get_downloaded_models())
        return downloaded == 1 and downloaded < MAX_MODELS
    
    def download_model(self, model_id: str, progress_callback=None) -> Dict:
        """Download a predefined model by its ID."""
        if model_id not in AVAILABLE_MODELS:
            return {"success": False, "error": f"Unknown model: {model_id}"}
        
        if not self.can_download_more():
            return {"success": False, "error": f"Maximum {MAX_MODELS} models allowed. Delete one first."}
        
        model_info = AVAILABLE_MODELS[model_id]
        model_path = self.models_dir / model_info["filename"]
        
        if model_path.exists():
            return {"success": True, "message": "Model already downloaded", "path": str(model_path)}
        
        logger.info(f"Downloading {model_info['name']} ({model_info['size_gb']}GB)...")
        
        try:
            response = requests.get(model_info["url"], stream=True)
            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0
            
            with open(model_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
                    downloaded += len(chunk)
                    
                    if progress_callback and total_size:
                        percent = (downloaded / total_size) * 100
                        progress_callback(percent, downloaded, total_size)
            
            logger.info(f"Downloaded {model_info['name']} successfully!")
            return {
                "success": True, 
                "message": f"Downloaded {model_info['name']}",
                "path": str(model_path)
            }
            
        except Exception as e:
            logger.error(f"Failed to download model: {e}")
            if model_path.exists():
                model_path.unlink()  # Clean up partial download
            return {"success": False, "error": str(e)}
    
    def delete_model(self, model_id: str) -> Dict:
        """Delete a downloaded model by ID (predefined or local)."""
        # Check if this would leave us with no models
        if len(self.get_downloaded_models()) <= MIN_MODELS:
            return {"success": False, "error": f"Cannot delete. At least {MIN_MODELS} model required."}

        model_path = self._resolve_path(model_id)
        if not model_path:
            return {"success": False, "error": f"Model '{model_id}' not found"}

        try:
            Path(model_path).unlink()
            logger.info(f"Deleted model: {model_id}")
            return {"success": True, "message": f"Deleted {model_id}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def _resolve_path(self, model_id: str) -> Optional[str]:
        """Internal helper: resolve a model_id to an absolute file path.
        
        Checks predefined models first, then falls back to scanning
        .gguf files by filename stem (the part before .gguf).
        """
        # 1. Predefined model
        if model_id in AVAILABLE_MODELS:
            model_path = self.models_dir / AVAILABLE_MODELS[model_id]["filename"]
            return str(model_path) if model_path.exists() else None

        # 2. Custom local model — match by stem (filename without .gguf)
        for gguf_file in self.models_dir.glob("*.gguf"):
            if gguf_file.stem == model_id:
                return str(gguf_file)

        return None

    def get_model_path(self, model_id: str) -> Optional[str]:
        """Get the absolute path to a model by its ID.
        
        Works for both predefined models (e.g. 'mistral-7b') and local
        GGUF files dropped into models/ (matched by filename stem).
        """
        return self._resolve_path(model_id)
    
    def get_default_model(self) -> Optional[Dict]:
        """Get the default (first available) model."""
        downloaded = self.get_downloaded_models()
        return downloaded[0] if downloaded else None
    
    def get_status(self) -> Dict:
        """Get overall model status."""
        downloaded = self.get_downloaded_models()
        available = self.get_available_for_download()
        
        return {
            "downloaded_models": downloaded,
            "available_for_download": available if self.can_download_more() else [],
            "total_downloaded": len(downloaded),
            "max_models": MAX_MODELS,
            "min_models": MIN_MODELS,
            "can_download_more": self.can_download_more(),
            "needs_model": self.needs_model(),
            "should_prompt_additional": self.should_prompt_for_additional()
        }


# Global instance
model_manager = ModelManager()