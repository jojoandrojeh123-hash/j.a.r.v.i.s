"""
agent.py — Agentic execution layer.

When the model produces a response containing code blocks, this module:
1. Detects executable code blocks (python, bash, javascript)
2. Writes each to a file in /workspace/home/
3. Executes in the container
4. Captures output
5. If output files are produced, copies them to /workspace/outputs/
6. Returns a structured list of "steps" that the UI renders as tool-use cards

This mirrors how Claude.ai uses its container: the model writes code,
the system executes it, output is shown, files are downloadable.
"""

import re
import uuid
import time
from pathlib import Path
from typing import Optional
import docker_sandbox as sandbox
import logging

logger = logging.getLogger(__name__)

# Languages we will auto-execute
EXECUTABLE = {"python", "py", "bash", "sh", "javascript", "js", "node"}

# Extensions for each language
LANG_EXT = {
    "python": "py", "py": "py",
    "bash": "sh", "sh": "sh",
    "javascript": "js", "js": "js", "node": "js",
}

# Patterns that suggest the script produces output files
FILE_OUTPUT_PATTERNS = [
    r'\.to_csv\s*\(',
    r'\.to_excel\s*\(',
    r'\.savefig\s*\(',
    r'open\s*\([\'"][^\'"]+[\'"]\s*,\s*[\'"]w',
    r'with open\s*\(',
    r'shutil\.copy',
    r'\.write\b',
    r'json\.dump\b',
    r'pickle\.dump\b',
    r'zipfile\.',
    r'tarfile\.',
]


def extract_code_blocks(text: str) -> list[dict]:
    """Pull all fenced code blocks out of a markdown string."""
    pattern = re.compile(r'```(\w+)?\n(.*?)```', re.DOTALL)
    blocks = []
    for m in pattern.finditer(text):
        lang = (m.group(1) or "").lower().strip()
        code = m.group(2)
        blocks.append({"lang": lang, "code": code, "start": m.start(), "end": m.end()})
    return blocks


def _may_produce_files(code: str) -> bool:
    return any(re.search(p, code) for p in FILE_OUTPUT_PATTERNS)


def _scan_new_outputs(before: set) -> list[dict]:
    """Return files that appeared in outputs/ after execution."""
    sandbox._ensure_dirs()
    after = {f for f in sandbox.OUTPUTS_DIR.rglob("*") if f.is_file()}
    new = after - before
    results = []
    for f in sorted(new):
        results.append({
            "name": f.name,
            "rel_path": str(f.relative_to(sandbox.WORKSPACE_DIR)).replace("\\", "/"),
            "size": f.stat().st_size,
        })
    return results


def run_agent_pass(response_text: str, auto_exec: bool = True) -> list[dict]:
    """
    Analyse the model response, execute any code blocks found,
    and return a list of step dicts for the UI to render.

    Each step dict:
    {
        "type": "write_file" | "exec" | "output_file" | "error",
        "lang": str,
        "filename": str,
        "code": str,           # for write_file
        "stdout": str,         # for exec
        "stderr": str,
        "ok": bool,
        "exit_code": int,
        "duration_ms": int,
        "output_files": [{"name", "rel_path", "size"}],  # files produced
    }
    """
    if not auto_exec:
        return []

    if not sandbox.is_docker_available():
        return [{"type": "error", "msg": "Docker not available — install Docker Desktop to enable code execution."}]

    blocks = extract_code_blocks(response_text)
    executable_blocks = [b for b in blocks if b["lang"] in EXECUTABLE]

    if not executable_blocks:
        return []

    # Ensure container is running
    sandbox.ensure_container()
    sandbox._ensure_dirs()

    steps = []

    for block in executable_blocks:
        lang = block["lang"]
        code = block["code"]
        ext = LANG_EXT.get(lang, "txt")
        filename = f"script_{uuid.uuid4().hex[:6]}.{ext}"
        container_path = f"{sandbox.CONTAINER_HOME}/{filename}"

        # Step 1: write the file
        wr = sandbox.write_file(filename, code, area="home")
        steps.append({
            "type": "write_file",
            "lang": lang,
            "filename": filename,
            "container_path": container_path,
            "code": code,
            "ok": wr["ok"],
        })

        if not wr["ok"]:
            steps.append({"type": "error", "msg": wr.get("msg", "Write failed")})
            continue

        # Step 2: execute
        snapshot = {f for f in sandbox.OUTPUTS_DIR.rglob("*") if f.is_file()}
        t0 = time.monotonic()

        if lang in ("python", "py"):
            exec_cmd = f"python {container_path}"
        elif lang in ("bash", "sh"):
            exec_cmd = f"bash {container_path}"
        else:
            exec_cmd = f"node {container_path}"

        # If code writes files, redirect output to outputs/
        if _may_produce_files(code):
            exec_cmd = f"cd {sandbox.CONTAINER_OUT} && {exec_cmd}"

        result = sandbox.exec_shell(exec_cmd, workdir=sandbox.CONTAINER_HOME, timeout=60)
        duration_ms = int((time.monotonic() - t0) * 1000)

        # Step 3: detect new output files
        new_files = _scan_new_outputs(snapshot)

        steps.append({
            "type": "exec",
            "lang": lang,
            "filename": filename,
            "command": exec_cmd,
            "stdout": result.get("stdout", ""),
            "stderr": result.get("stderr", ""),
            "exit_code": result.get("exit_code", -1),
            "ok": result.get("ok", False),
            "duration_ms": duration_ms,
            "output_files": new_files,
        })

        # Clean up the script file (keep outputs)
        try:
            (sandbox.HOME_DIR / filename).unlink(missing_ok=True)
        except Exception:
            pass

    return steps