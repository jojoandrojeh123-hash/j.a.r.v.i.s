import json
import shutil
from pathlib import Path
from typing import Optional, List
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, UploadFile, File, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel

from config import settings
from llm_engine import llm_engine
from model_manager import model_manager
from chat_store import create_chat, get_chat, list_chats, append_messages, rename_chat, delete_chat
import docker_sandbox as sandbox
from agent import run_agent_pass
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

UPLOADS_DIR = Path("uploads")
UPLOADS_DIR.mkdir(exist_ok=True)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting LocalAI...")
    status = model_manager.get_status()
    if status["needs_model"]:
        logger.warning("No models found.")
    else:
        if not llm_engine.initialize():
            logger.warning("LLM failed to initialize")
    yield
    logger.info("Shutting down...")


app = FastAPI(title="LocalAI", version="1.0.0", lifespan=lifespan)
app.mount("/static", StaticFiles(directory="static"), name="static")


# ── Pydantic models ──────────────────────────────────────────────
class ModelAction(BaseModel):
    action: str
    model_id: str

class SettingsUpdate(BaseModel):
    n_ctx: Optional[int] = None
    n_gpu_layers: Optional[int] = None
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    system_prompt: Optional[str] = None
    auto_exec: Optional[bool] = None

class RenameChat(BaseModel):
    title: str

class FileWrite(BaseModel):
    path: str
    content: str
    area: str = "home"

class FileDelete(BaseModel):
    path: str

class FileCopy(BaseModel):
    rel_path: str

class CodeExec(BaseModel):
    code: str
    language: str = "python"
    timeout: int = 30

class ShellExec(BaseModel):
    command: str
    workdir: str = sandbox.CONTAINER_HOME
    timeout: int = 30

class PackageInstall(BaseModel):
    packages: List[str]
    manager: str = "pip"

class HostFileWrite(BaseModel):
    abs_path: str
    content: str

class ContainerConfig(BaseModel):
    mem: str = "1g"
    cpus: str = "2.0"


# Runtime toggle for auto-execution
AUTO_EXEC = True


# ── UI ──────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def root():
    return FileResponse("static/index.html")


# ── WebSocket chat ───────────────────────────────────────────────
@app.websocket("/ws/chat")
async def websocket_chat(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            data = await websocket.receive_text()
            msg_data = json.loads(data)
            action = msg_data.get("action", "chat")

            # Stop signal
            if action == "stop":
                llm_engine.stop()
                await websocket.send_json({"type": "stopped"})
                continue

            user_message = msg_data.get("message", "").strip()
            chat_id = msg_data.get("chat_id")
            attachments = msg_data.get("attachments", [])

            if not user_message and not attachments:
                continue
            if not llm_engine.model:
                await websocket.send_json({"type": "error", "content": "No model loaded."})
                continue

            # Build message with attachment context
            full_message = user_message
            if attachments:
                parts = [user_message] if user_message else []
                for att in attachments:
                    if att.get("content"):
                        # Also write uploaded text files into the container workspace
                        if sandbox.is_docker_available():
                            sandbox.ensure_container()
                            sandbox.write_file(f"uploads/{att['name']}", att['content'], area="home")
                        parts.append(
                            f"\n\n[Uploaded file: {att['name']}]\n"
                            f"Path in container: /workspace/home/uploads/{att['name']}\n"
                            f"```\n{att['content'][:4000]}\n```"
                        )
                full_message = "\n".join(parts)

            # Create chat on first message
            if not chat_id:
                chat = create_chat(full_message, llm_engine.current_model_id or "unknown")
                chat_id = chat["id"]
                await websocket.send_json({
                    "type": "chat_created",
                    "chat_id": chat_id,
                    "title": chat["title"]
                })

            append_messages(chat_id, [{"role": "user", "content": full_message}])

            # ── Stream the model response ──────────────────────────
            full_response = ""
            try:
                for token in llm_engine.generate(full_message, stream=True):
                    full_response += token
                    await websocket.send_json({"type": "token", "content": token})
            except Exception as e:
                await websocket.send_json({"type": "error", "content": str(e)})
                full_response = f"[Error: {e}]"

            # ── Agent pass: auto-execute code blocks ───────────────
            steps = []
            if full_response and AUTO_EXEC and sandbox.is_docker_available():
                try:
                    steps = run_agent_pass(full_response, auto_exec=True)
                except Exception as e:
                    logger.error(f"Agent pass failed: {e}")

            # Send done signal with agent steps
            await websocket.send_json({
                "type": "done",
                "chat_id": chat_id,
                "steps": steps,
            })

            if full_response:
                append_messages(chat_id, [{"role": "assistant", "content": full_response}])

    except WebSocketDisconnect:
        logger.info("WebSocket disconnected")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")


# ── File upload ──────────────────────────────────────────────────
@app.post("/api/upload-attachment")
async def upload_attachment(file: UploadFile = File(...)):
    content = await file.read()
    mime = file.content_type or ""
    text_exts = {
        ".py",".js",".ts",".html",".css",".md",".txt",".json",
        ".yaml",".yml",".sh",".bat",".c",".cpp",".h",".rs",
        ".go",".java",".rb",".php",".sql",".xml",".toml",".ini",".cfg",".env"
    }
    is_text = (
        any(mime.startswith(t) for t in ["text/","application/json","application/xml"])
        or Path(file.filename).suffix.lower() in text_exts
    )
    if is_text:
        decoded = content.decode("utf-8", errors="replace")
        # Write to container upload zone
        if sandbox.is_docker_available():
            sandbox.ensure_container()
            sandbox.write_file(f"uploads/{file.filename}", decoded, area="home")
        return {
            "ok": True, "name": file.filename, "mime": mime,
            "content": decoded, "type": "text",
            "container_path": f"/workspace/home/uploads/{file.filename}"
        }
    # Binary — save to uploads/ on host only
    (UPLOADS_DIR / file.filename).write_bytes(content)
    return {
        "ok": True, "name": file.filename, "mime": mime, "type": "binary",
        "note": "Binary saved. Reference it from your prompt for the model to process."
    }


# ── Sandbox: container lifecycle ─────────────────────────────────
@app.get("/api/sandbox/status")
async def sandbox_status():
    if not sandbox.is_docker_available():
        return {"docker": False, "container": None, "workspace": None}
    return {
        "docker": True,
        "container": sandbox.container_status(),
        "workspace": sandbox.workspace_summary(),
    }

@app.post("/api/sandbox/start")
async def sandbox_start(body: ContainerConfig = ContainerConfig()):
    return sandbox.ensure_container(mem=body.mem, cpus=body.cpus)

@app.post("/api/sandbox/stop")
async def sandbox_stop():
    return sandbox.stop_container()

@app.post("/api/sandbox/restart")
async def sandbox_restart():
    return sandbox.restart_container()

@app.get("/api/sandbox/logs")
async def sandbox_logs(lines: int = 100):
    return sandbox.get_container_logs(lines)


# ── Sandbox: execution ───────────────────────────────────────────
@app.post("/api/sandbox/exec")
async def sandbox_exec(body: CodeExec):
    return sandbox.exec_code(body.code, body.language, body.timeout)

@app.post("/api/sandbox/shell")
async def sandbox_shell(body: ShellExec):
    return sandbox.exec_shell(body.command, body.workdir, body.timeout)


# ── Sandbox: packages ────────────────────────────────────────────
@app.post("/api/sandbox/packages/install")
async def sandbox_install(body: PackageInstall):
    return sandbox.install_packages(body.packages, body.manager)

@app.get("/api/sandbox/packages")
async def sandbox_packages(manager: str = "pip"):
    return sandbox.list_installed_packages(manager)


# ── Sandbox: files ───────────────────────────────────────────────
@app.get("/api/sandbox/files")
async def sandbox_list(path: str = "", area: str = "home"):
    return sandbox.list_files(path, area)

@app.post("/api/sandbox/files")
async def sandbox_write(body: FileWrite):
    return sandbox.write_file(body.path, body.content, body.area)

@app.get("/api/sandbox/files/read")
async def sandbox_read(path: str):
    return sandbox.read_file(path)

@app.delete("/api/sandbox/files")
async def sandbox_delete(body: FileDelete):
    return sandbox.delete_file(body.path)

@app.post("/api/sandbox/files/copy-to-outputs")
async def sandbox_copy_output(body: FileCopy):
    return sandbox.copy_to_outputs(body.rel_path)

@app.post("/api/sandbox/tmp/clean")
async def sandbox_clean():
    return sandbox.clean_tmp()

@app.get("/api/sandbox/download")
async def sandbox_download(path: str):
    target = (sandbox.WORKSPACE_DIR / path).resolve()
    if not str(target).startswith(str(sandbox.WORKSPACE_DIR)):
        raise HTTPException(status_code=400, detail="Invalid path")
    if not target.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(str(target), filename=target.name, media_type="application/octet-stream")


# ── Host filesystem ──────────────────────────────────────────────
@app.get("/api/host/files")
async def host_list(path: str = "/"):
    try:
        target = Path(path)
        if not target.exists():
            return {"ok": False, "entries": [], "msg": "Not found"}
        entries = []
        try:
            for item in sorted(target.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
                try:
                    entries.append({
                        "name": item.name, "is_dir": item.is_dir(),
                        "size": item.stat().st_size if item.is_file() else 0,
                        "path": str(item).replace("\\", "/"),
                    })
                except PermissionError:
                    pass
        except PermissionError:
            return {"ok": False, "entries": [], "msg": "Permission denied"}
        return {"ok": True, "entries": entries, "cwd": str(target).replace("\\", "/")}
    except Exception as e:
        return {"ok": False, "entries": [], "msg": str(e)}

@app.get("/api/host/read")
async def host_read(path: str):
    try:
        t = Path(path)
        if not t.exists() or not t.is_file():
            return {"ok": False, "content": "", "msg": "Not found"}
        return {"ok": True, "content": t.read_text(encoding="utf-8", errors="replace")}
    except Exception as e:
        return {"ok": False, "content": "", "msg": str(e)}

@app.post("/api/host/write")
async def host_write(body: HostFileWrite):
    try:
        t = Path(body.abs_path)
        t.parent.mkdir(parents=True, exist_ok=True)
        t.write_text(body.content, encoding="utf-8")
        return {"ok": True, "path": str(t)}
    except Exception as e:
        return {"ok": False, "msg": str(e)}

@app.get("/api/host/download")
async def host_download(path: str):
    t = Path(path)
    if not t.exists() or not t.is_file():
        raise HTTPException(status_code=404, detail="Not found")
    return FileResponse(str(t), filename=t.name, media_type="application/octet-stream")


# ── Chat history ─────────────────────────────────────────────────
@app.get("/api/chats")
async def api_list_chats(): return list_chats()

@app.get("/api/chats/{chat_id}")
async def api_get_chat(chat_id: str):
    c = get_chat(chat_id)
    if not c: raise HTTPException(status_code=404, detail="Not found")
    return c

@app.patch("/api/chats/{chat_id}")
async def api_rename_chat(chat_id: str, body: RenameChat):
    c = rename_chat(chat_id, body.title)
    if not c: raise HTTPException(status_code=404, detail="Not found")
    return {"success": True, "title": c["title"]}

@app.delete("/api/chats/{chat_id}")
async def api_delete_chat(chat_id: str):
    if not delete_chat(chat_id): raise HTTPException(status_code=404, detail="Not found")
    llm_engine.clear_history()
    return {"success": True}


# ── Models ───────────────────────────────────────────────────────
@app.get("/api/models")
async def get_models():
    s = model_manager.get_status()
    s["current_model"] = llm_engine.current_model_id
    s["engine_status"] = llm_engine.get_status()
    return s

@app.post("/api/models")
async def model_action(action: ModelAction):
    if action.action == "download":
        r = model_manager.download_model(action.model_id)
        if r["success"] and len(model_manager.get_downloaded_models()) == 1:
            llm_engine.initialize(action.model_id)
        return r
    elif action.action == "delete":
        if llm_engine.current_model_id == action.model_id:
            others = [m for m in model_manager.get_downloaded_models() if m["id"] != action.model_id]
            if others: llm_engine.switch_model(others[0]["id"])
            else: raise HTTPException(status_code=400, detail="Cannot delete the only model.")
        return model_manager.delete_model(action.model_id)
    elif action.action == "switch":
        if llm_engine.switch_model(action.model_id): return {"success": True}
        raise HTTPException(status_code=500, detail="Failed to switch")
    raise HTTPException(status_code=400, detail=f"Unknown action: {action.action}")


# ── Settings ─────────────────────────────────────────────────────
@app.get("/api/settings")
async def get_settings():
    return {
        "n_ctx": settings.N_CTX, "n_gpu_layers": settings.N_GPU_LAYERS,
        "max_tokens": settings.MAX_TOKENS, "temperature": settings.TEMPERATURE,
        "system_prompt": llm_engine.system_prompt,
        "host": settings.HOST, "port": settings.PORT,
        "auto_exec": AUTO_EXEC,
    }

@app.post("/api/settings")
async def update_settings(update: SettingsUpdate):
    global AUTO_EXEC
    changed = []
    env_path = Path(".env")
    lines = env_path.read_text(encoding="utf-8").splitlines() if env_path.exists() else []
    def set_env(k, v):
        nonlocal lines
        for i, l in enumerate(lines):
            if l.startswith(f"{k}="): lines[i] = f"{k}={v}"; return
        lines.append(f"{k}={v}")
    if update.n_ctx is not None:
        settings.N_CTX = update.n_ctx; set_env("N_CTX", update.n_ctx); changed.append("n_ctx")
    if update.n_gpu_layers is not None:
        settings.N_GPU_LAYERS = update.n_gpu_layers; set_env("N_GPU_LAYERS", update.n_gpu_layers); changed.append("n_gpu_layers")
    if update.max_tokens is not None:
        settings.MAX_TOKENS = update.max_tokens; set_env("MAX_TOKENS", update.max_tokens); changed.append("max_tokens")
    if update.temperature is not None:
        settings.TEMPERATURE = update.temperature; set_env("TEMPERATURE", update.temperature); changed.append("temperature")
    if update.system_prompt is not None:
        p = Path(settings.SYSTEM_PROMPT_FILE); p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(update.system_prompt, encoding="utf-8"); llm_engine.reload_system_prompt(); changed.append("system_prompt")
    if update.auto_exec is not None:
        AUTO_EXEC = update.auto_exec; changed.append("auto_exec")
    env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"success": True, "changed": changed}

@app.post("/api/clear-history")
async def clear_history():
    llm_engine.clear_history(); return {"success": True}

@app.get("/api/health")
async def health():
    return {"status": "online", "model_loaded": llm_engine.model is not None,
            "current_model": llm_engine.current_model_id, "auto_exec": AUTO_EXEC}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host=settings.HOST, port=settings.PORT, reload=True)