import os
from pydantic_settings import BaseSettings
from pathlib import Path

class Settings(BaseSettings):
    # Server settings
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # Model settings - Using Mistral 7B Instruct GGUF (good balance of speed/quality)
    MODEL_PATH: str = "models/model2.gguf"
    MODEL_URL: str = "https://huggingface.co/TheBloke/Mistral-7B-Instruct-GGUF/resolve/main/mistral-7b-instruct.gguf"
    
    # LLM settings
    N_CTX: int = 4096
    N_GPU_LAYERS: int = -1  # Set to -1 for full GPU, 0 for CPU only
    MAX_TOKENS: int = 1000000000
    TEMPERATURE: float = 0.7
    
    # Paths
    BASE_DIR: Path = Path(__file__).parent
    MODELS_DIR: Path = BASE_DIR / "models"
    PROMPTS_DIR: Path = BASE_DIR / "prompts"
    STATIC_DIR: Path = BASE_DIR / "static"
    
    # System prompt file
    SYSTEM_PROMPT_FILE: str = "prompts/jarvis_system_prompt.txt"
    
    # Security - Add allowed commands (empty = all allowed, be careful!)
    ALLOWED_COMMANDS: list = []
    ENABLE_SYSTEM_CONTROL: bool = True
    
    class Config:
        env_file = ".env"

settings = Settings()

# Create directories
settings.MODELS_DIR.mkdir(exist_ok=True)
settings.PROMPTS_DIR.mkdir(exist_ok=True)
settings.STATIC_DIR.mkdir(exist_ok=True)
