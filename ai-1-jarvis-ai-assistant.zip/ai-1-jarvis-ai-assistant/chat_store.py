"""
chat_store.py — persistent chat history stored as JSON files in chats/
Each chat is one file: chats/<id>.json
{
  "id": "abc123",
  "title": "First message preview...",
  "created_at": "2026-01-01T12:00:00",
  "updated_at": "2026-01-01T12:05:00",
  "model": "rojeh",
  "messages": [
    {"role": "user",      "content": "Hello"},
    {"role": "assistant", "content": "Hi there!"}
  ]
}
"""
import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Dict

CHATS_DIR = Path("chats")
CHATS_DIR.mkdir(exist_ok=True)


def _chat_path(chat_id: str) -> Path:
    return CHATS_DIR / f"{chat_id}.json"


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _title_from_message(text: str, max_len: int = 50) -> str:
    """Use the first user message as the chat title."""
    text = text.strip().replace("\n", " ")
    return text[:max_len] + ("…" if len(text) > max_len else "")


# ── CRUD ──────────────────────────────────────────────

def create_chat(first_message: str, model: str) -> Dict:
    chat_id = uuid.uuid4().hex[:12]
    now = _now()
    chat = {
        "id": chat_id,
        "title": _title_from_message(first_message),
        "created_at": now,
        "updated_at": now,
        "model": model,
        "messages": [],
    }
    _save(chat)
    return chat


def get_chat(chat_id: str) -> Optional[Dict]:
    p = _chat_path(chat_id)
    if not p.exists():
        return None
    return json.loads(p.read_text(encoding="utf-8"))


def list_chats() -> List[Dict]:
    """Return all chats sorted newest-first, without messages (summary only)."""
    chats = []
    for p in CHATS_DIR.glob("*.json"):
        try:
            chat = json.loads(p.read_text(encoding="utf-8"))
            chats.append({
                "id": chat["id"],
                "title": chat.get("title", "Untitled"),
                "created_at": chat.get("created_at", ""),
                "updated_at": chat.get("updated_at", ""),
                "model": chat.get("model", ""),
                "message_count": len(chat.get("messages", [])),
            })
        except Exception:
            pass
    chats.sort(key=lambda c: c["updated_at"], reverse=True)
    return chats


def append_messages(chat_id: str, messages: List[Dict]) -> Optional[Dict]:
    """Add one or more messages to an existing chat."""
    chat = get_chat(chat_id)
    if not chat:
        return None
    chat["messages"].extend(messages)
    chat["updated_at"] = _now()
    _save(chat)
    return chat


def rename_chat(chat_id: str, title: str) -> Optional[Dict]:
    chat = get_chat(chat_id)
    if not chat:
        return None
    chat["title"] = title.strip()[:80]
    chat["updated_at"] = _now()
    _save(chat)
    return chat


def delete_chat(chat_id: str) -> bool:
    p = _chat_path(chat_id)
    if p.exists():
        p.unlink()
        return True
    return False


def _save(chat: Dict):
    _chat_path(chat["id"]).write_text(
        json.dumps(chat, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )